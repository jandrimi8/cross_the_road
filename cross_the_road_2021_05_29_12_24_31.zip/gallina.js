class gallina {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  display() {
    fill(255);
    rect(this.x, this.y, 40, 40);
    if (loged[0] == true) {
      this.x += terrenos[loged[2]].logs[loged[1]].vel;
    } else {
      this.pos_lerp = norm(this.x, 0,500);
      this.pos_lerp-=0.05;
      this.pos_lerp =round(this.pos_lerp,1)
      this.pos_lerp+=0.05
      this.pos_lerp =round(this.pos_lerp,2)
      this.x= lerp(0,500,this.pos_lerp);
    }
  }
  move(mov) {
    this.x += mov;
  }
}
