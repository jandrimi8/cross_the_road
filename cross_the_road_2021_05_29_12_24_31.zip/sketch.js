let terrenos;
let obstaculos;
let player;
let lost = false;
let center;
let end = false;
let loged = [];
let wait = false;
let rt;
let offset;
let test;
function setup() {
  createCanvas(1000, 600);
  center = width / 2;
  rectMode(CENTER);
  textAlign(CENTER, CENTER);
  loged[0] = false;
  terrenos = new Array(2);
  player = new gallina(475, 425);
  terrenos[4] = new land(-75);
  terrenos[3] = new river(0);
  terrenos[2] = new land(75);
  terrenos[1] = new road(150);
  terrenos[0] = new land(225);
}

function draw() {
  if (end == false) {
    background(0, 180, 0);
    for (let i = 0; i <= terrenos.length - 1; i++) {
      terrenos[i].display(i);
    }
    player.display();
    wait = false;
  } else {
    textSize(50);
    text("END OF THE ROAD", 375, 275);
    text("score:coming soon", 375, 325);
  }
}
function keyPressed() {
  if (keyCode === UP_ARROW) {
    for (let i = 0; i <= terrenos.length - 1; i++) {
      terrenos[i].move(50);
      loged[0] = false;
      wait = true;
    }
      terrain_generator();
  }
  if (keyCode === RIGHT_ARROW && player.x < 950) {
    player.move(50);
    loged[0] = false;
    wait = true;
  }
  if (keyCode === LEFT_ARROW && player.x > 50) {
    player.move(-50);
    loged[0] = false;
    wait = true;
  }
}
function terrain_generator() {
  rt=int(random(0,3))
  if(terrenos[terrenos.length-1].type==1){
  offset=25;
  }else{
  offset=50;
  }

  if(rt==0){
    terrenos[terrenos.length] = new land(terrenos[terrenos.length-1].y-(offset+25));
  }else if(rt==1){
    terrenos[terrenos.length] = new road(terrenos[terrenos.length-1].y-(offset+50));
  }else{
    terrenos[terrenos.length] = new river(terrenos[terrenos.length-1].y-(offset+50));
  }
}
