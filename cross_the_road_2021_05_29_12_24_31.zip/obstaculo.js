class tree{
  constructor(x,y){
    this.y=y;
    this.x=x;
  }
  display(nt){
    this.y=terrenos[nt].y
    fill(0,130,0);
   ellipse(this.x,this.y,50,50);
    if(this.x==player.x&&this.y==player.y){
      end=true;
       
    }
  }
  
  move(mov){
    this.y+=mov
    
  }
}
class car{
  constructor(dir,y,vel){
    if(dir==1){
    this.yc=-25;
    this.x=-35;
    this.vel=vel;
    }else if(dir==0){
    this.yc=25;
    this.x=1025;
    this.vel=vel*-1;
    }

  }
  display(nt){
    fill(0,0,150);
    this.y=terrenos[nt].y+this.yc;
   rect(this.x,this.y,70,40);
    this.x+=this.vel;
     if(this.x-25 <= player.x+20&&this.x+25>=player.x-20&&this.y==player.y){
      end=true;
       
    }
  }
  
  move(mov){
    this.y+=mov
    
  }
}
class loog{
  constructor(dir,y,vel){
    
    if(dir==1){
    this.yc=-25;
    this.x=-35;
    this.vel=vel;
    }else if(dir==0){
    this.yc=25;
    this.x=1025;
    this.vel=vel*-1;
    }

  }
  display(nt,no){
    
    fill(150,40,0);
    this.y=terrenos[nt].y+this.yc;
   rect(this.x,this.y,100,40);
    this.x+=this.vel;
     if(this.x-50 <= player.x-5&&this.x+50>=player.x+5&&this.y==player.y){
      loged[0]=true;
       loged[1]=no;
       loged[2]=nt;
    }
    if(this.y==player.y&&loged[0]==false&&wait==false){
      end=true;
    }
    
  }
  
  move(mov){
    this.y+=mov
    
  }
}