class road{
  constructor(y){
    this.type=2;
    this.y=y;
    this.x=center
    this.cars=[];
    this.dir=0;
    this.timer=0;
  }
  display(nt){
    fill(0);
   rect(this.x,this.y,1000,100);
    fill(255);
    if(this.y>700){
       for(let i=0;i< this.cars.length;i++){
         this.cars.splice(i,1);
       }
       }
    for(let i=0;i<11;i++){
    rect(i*100,this.y,50,20);
      
    }
    
    if(this.timer==0&&this.y<650){
       this.dir = int(random(0,2));
      //print(this.dir);
       this.cars[this.cars.length]=new car(this.dir,this.y,5);
      this.timer=int(random(5,15));
       }
    
    if (frameCount % 10 == 0&&this.timer>0){
      this.timer--;
      
    }
    for(let i=0;i< this.cars.length;i++){
    this.cars[i].display(nt);
      if(this.cars[i].x<=-35){
         this.cars.splice(i,1);
         }
  }
  }
  
  move(mov){
    this.y+=mov
    
  }

}
class river{
  constructor(y){
    this.type=3;
    this.y=y;
    this.x=center
    this.logs=[];
    this.dir=0;
    this.timer=0;
  }
  display(nt){
    fill(0,0,200);
    noStroke();
   rect(this.x,this.y,1000,100);
    stroke(51);
    fill(255);
    if(this.y>700){
       for(let i=0;i< this.logs.length;i++){
          this.logs.splice(i,1);
       }
       }
    
    if(this.timer==0&&this.y<650){
       this.dir = int(random(0,2));
       this.logs[this.logs.length]=new loog(this.dir,this.y,2);
      this.timer=int(random(5,15));
       }
    
    if (frameCount % 10 == 0&&this.timer>0){
      this.timer--;
      
    }
    for(let i=0;i< this.logs.length;i++){
    this.logs[i].display(nt,i);
      if(this.logs[i].x<=-50){
         this.logs.splice(i,1);
         }
  }
  }
  
  move(mov){
    this.y+=mov
    
  }

}
class land{
  constructor(y){
    this.type=1;
    this.y=y;
    this.x=center
    this.trees =new Array(20);
    
    for(let i=0;i<=8;i++){
      this.r =int(random(1,11))
      if(this.r<=9-i){
         this.trnsform_pos = ((i+1)*50)-25
         this.trees[i]=new tree(this.trnsform_pos,this.y);
      }
    }
    this.chance=-1;
    for(let i=19;i>=12;i--){
      this.chance++;
      this.r =int(random(0,11))
      if(this.r<=9-this.chance){
         this.trnsform_pos = ((i+1)*50)-25
         this.trees[i]=new tree(this.trnsform_pos,this.y);
      }
    }
  }
  display(nt){
    for(let i=0;i<= 19;i++){
    if(this.trees[i]!=undefined){
    this.trees[i].display(nt)
    }
    }
    if(this.y>700){
       for(let i=0;i< this.trees.length;i++){
         this.trees.splice(i,1);
       }
       }

    

    
  }
  
  move(mov){
    this.y+=mov
    
  }

}