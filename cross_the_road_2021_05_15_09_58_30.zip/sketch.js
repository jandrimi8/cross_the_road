
let terrenos;
let obstaculos;
let player;
let lost = false;
let center;

function setup() {
  createCanvas(750, 600);
  center=width/2
  rectMode(CENTER);
  terrenos = new road(50);
  obstaculos = new tree(125,125);
  player = new gallina(center,425);
}

function draw() {
  background(0,180,0);
  terrenos.display();
  obstaculos.display();
  player.display();
  

}
function keyPressed() {
  if(keyCode===UP_ARROW){
  terrenos.move(50);
  obstaculos.move(50);
}
  if(keyCode===RIGHT_ARROW&&player.x<700){
  player.move(50);
}
  if(keyCode===LEFT_ARROW&&player.x>50){
  player.move(-50);
}
}