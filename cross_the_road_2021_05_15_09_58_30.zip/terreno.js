class road{
  constructor(y){
    this.y=y;
    this.x=center
    this.cars=[];
    
    this.timer=0;
  }
  display(){
    fill(0);
   rect(this.x,this.y,750,100);
    fill(255);
    for(let i=0;i<8;i++){
    rect(i*100,this.y,50,20);
      
    }
    
    if(this.timer==0){
       this.create_car();
      this.timer=int(random(6,18));
       }
    
    if (frameCount % 10 == 0&&this.timer>0){
      this.timer--;
      print(this.timer);
    }
    for(let i=0;i< this.cars.length;i++){
    this.cars[i].display();
  }
  }
  
  move(mov){
    this.y+=mov
    
  }
  create_car(){
    this.cars[this.cars.length]=new car(785,this.y+25,-5);
  }
}