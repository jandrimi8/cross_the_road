class gallina {
  constructor(x, y) {
    this.x=x;
    this.y=y;
  }
  display() {
    fill(255)
  rect(this.x,this.y,40,40);
  }
  move(mov){
    this.x+=mov
    
  }
}
