class tree{
  constructor(x,y){
    this.y=y;
    this.x=x;
  }
  display(){
    fill(0,130,0);
   ellipse(this.x,this.y,50,50);
    
  }
  
  move(mov){
    this.y+=mov
    
  }
}
class car{
  constructor(x,y,vel){
    this.y=y;
    this.x=x;
    this.vel=vel;

  }
  display(){
    fill(0,0,150);
    this.y=terrenos.y+25;
   rect(this.x,this.y,70,40);
    this.x+=this.vel;
  }
  
  move(mov){
    this.y+=mov
    
  }
}